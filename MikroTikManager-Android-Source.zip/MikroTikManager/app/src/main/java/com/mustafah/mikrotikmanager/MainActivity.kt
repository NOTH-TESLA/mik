package com.mustafah.mikrotikmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Orange = Color(0xFFFF8A24)
private val Muted = Color(0xFF9EACC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ManagerApp() }
    }
}

data class RouterSnapshot(
    val identity: String,
    val version: String,
    val board: String,
    val uptime: String,
    val cpu: String,
    val memory: String,
    val interfaces: List<Map<String, String>>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerApp() {
    var address by remember { mutableStateOf("192.168.10.1") }
    var port by remember { mutableStateOf("8729") }
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }
    var useTls by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var snapshot by remember { mutableStateOf<RouterSnapshot?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (snapshot == null) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(18.dp), color = Orange, modifier = Modifier.size(54.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Router, null, tint = Navy, modifier = Modifier.size(32.dp))
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("MikroTik Manager", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("NATIVE ROUTER CONTROL", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                    }
                    Spacer(Modifier.height(34.dp))
                    Text("اتصال به روتر", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("اطلاعات اتصال روتر MikroTik را وارد کنید.", color = Muted)
                    Spacer(Modifier.height(22.dp))
                    InputField("IP Address / Host", address, { address = it }, KeyboardType.Uri)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { InputField("API Port", port, { port = it }, KeyboardType.Number) }
                        Box(Modifier.weight(1f)) { InputField("Username", username, { username = it }) }
                    }
                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        colors = fieldColors()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = useTls, onCheckedChange = {
                            useTls = it
                            port = if (it) "8729" else "8728"
                        })
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("TLS encryption")
                            Text("اتصال رمزگذاری‌شده (پیشنهادی)", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    error?.let {
                        Text(it, color = Color(0xFFFF7777), modifier = Modifier.padding(bottom = 10.dp))
                    }
                    Button(
                        onClick = {
                            error = null
                            loading = true
                            scope.launch {
                                try {
                                    val p = port.toInt()
                                    snapshot = withContext(Dispatchers.IO) {
                                        RouterApi.connect(address.trim(), p, username.trim(), password, useTls)
                                    }
                                } catch (e: Exception) {
                                    error = e.message ?: "اتصال ناموفق بود."
                                } finally { loading = false }
                            }
                        },
                        enabled = !loading && address.isNotBlank() && username.isNotBlank() && port.toIntOrNull() != null,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Navy)
                    ) {
                        if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Navy)
                        else {
                            Icon(Icons.Default.Link, null)
                            Spacer(Modifier.width(8.dp))
                            Text("اتصال به روتر", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("نکته: API باید در روتر فعال باشد و دسترسی شبکه اجازه اتصال بدهد.", color = Muted, fontSize = 12.sp)
                    Text("By Mustafah", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 24.dp))
                }
            } else {
                Dashboard(snapshot!!, onDisconnect = { snapshot = null; password = "" })
            }
        }
    }
}

@Composable
private fun InputField(label: String, value: String, onValue: (String) -> Unit, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        colors = fieldColors()
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Orange, unfocusedBorderColor = Color(0xFF40506A),
    focusedLabelColor = Orange, cursorColor = Orange
)

@Composable
private fun Dashboard(data: RouterSnapshot, onDisconnect: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("MikroTik Manager", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(data.identity, color = Muted)
            }
            IconButton(onClick = onDisconnect) { Icon(Icons.Default.Logout, "Disconnect", tint = Orange) }
        }
        Spacer(Modifier.height(18.dp))
        Text("ROUTER OVERVIEW", color = Orange, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(10.dp))
        InfoCard("Router board", data.board)
        InfoCard("RouterOS version", data.version)
        InfoCard("Uptime", data.uptime)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { InfoCard("CPU", data.cpu) }
            Box(Modifier.weight(1f)) { InfoCard("Memory free", data.memory) }
        }
        Spacer(Modifier.height(18.dp))
        Text("INTERFACES", color = Orange, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        if (data.interfaces.isEmpty()) Text("No interface data.", color = Muted)
        data.interfaces.forEach { item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text(item["name"] ?: "Interface", fontWeight = FontWeight.Bold)
                    Text(item["type"] ?: "", color = Muted, fontSize = 12.sp)
                    Text("Running: ${item["running"] ?: "unknown"}", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Text("By Mustafah", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally).padding(20.dp))
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(5.dp))
            Text(value.ifBlank { "—" }, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/**
 * Minimal RouterOS API sentence client.
 * Uses TLS by default. For production, replace the permissive LAN certificate
 * strategy with certificate/hostname validation or certificate pinning.
 */
private object RouterApi {
    fun connect(host: String, port: Int, user: String, pass: String, tls: Boolean): RouterSnapshot {
        require(host.isNotBlank()) { "آدرس روتر وارد نشده است." }
        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 7000)
        raw.soTimeout = 7000
        val socket: Socket = if (tls) {
            // Trust only the device's normal Android trust store in this starter.
            val ssl = SSLSocketFactory.getDefault().createSocket(raw, host, port, true) as SSLSocket
            ssl.startHandshake()
            ssl
        } else raw

        socket.use { s ->
            val input = BufferedInputStream(s.getInputStream())
            val output = BufferedOutputStream(s.getOutputStream())
            val login = command(input, output, listOf("/login", "=name=$user", "=password=$pass"))
            if (login.any { it["message"]?.contains("invalid", true) == true }) {
                throw IllegalStateException("نام کاربری یا رمز عبور نادرست است.")
            }
            val resources = command(input, output, listOf("/system/resource/print")).firstOrNull() ?: emptyMap()
            val identity = command(input, output, listOf("/system/identity/print")).firstOrNull() ?: emptyMap()
            val interfaces = command(input, output, listOf("/interface/print"))
            return RouterSnapshot(
                identity = identity["name"] ?: host,
                version = resources["version"] ?: "Unknown",
                board = resources["board-name"] ?: resources["architecture-name"] ?: "Unknown",
                uptime = resources["uptime"] ?: "Unknown",
                cpu = listOfNotNull(resources["cpu-load"]?.let { "$it%" }, resources["cpu"]?.takeIf { it.isNotBlank() }).joinToString(" · ").ifBlank { "Unknown" },
                memory = resources["free-memory"]?.let { bytes ->
                    runCatching { "${"%.1f".format(bytes.toDouble() / 1024 / 1024)} MB" }.getOrDefault(bytes)
                } ?: "Unknown",
                interfaces = interfaces.map {
                    mapOf("name" to (it["name"] ?: ""), "type" to (it["type"] ?: ""), "running" to (it["running"] ?: "no"))
                }
            )
        }
    }

    private fun command(input: BufferedInputStream, output: BufferedOutputStream, words: List<String>): List<Map<String, String>> {
        words.forEach { writeWord(output, it) }
        writeLength(output, 0)
        output.flush()
        val rows = mutableListOf<Map<String, String>>()
        var current = mutableMapOf<String, String>()
        while (true) {
            val sentence = mutableListOf<String>()
            while (true) {
                val len = readLength(input)
                if (len == 0) break
                val bytes = ByteArray(len)
                var offset = 0
                while (offset < len) {
                    val n = input.read(bytes, offset, len - offset)
                    if (n < 0) throw IllegalStateException("ارتباط روتر قطع شد.")
                    offset += n
                }
                sentence.add(bytes.toString(Charsets.UTF_8))
            }
            if (sentence.isEmpty()) continue
            when (sentence[0]) {
                "!re" -> {
                    current = mutableMapOf()
                    sentence.drop(1).forEach { w ->
                        if (w.startsWith("=")) {
                            val p = w.substring(1).split("=", limit = 2)
                            if (p.size == 2) current[p[0]] = p[1]
                        }
                    }
                    rows.add(current)
                }
                "!trap" -> {
                    val msg = sentence.firstOrNull { it.startsWith("=message=") }?.substringAfter("=message=")
                    throw IllegalStateException(msg ?: "RouterOS API command failed.")
                }
                "!fatal" -> throw IllegalStateException("RouterOS API fatal error.")
                "!done" -> return rows
            }
        }
    }

    private fun writeWord(out: BufferedOutputStream, word: String) {
        val bytes = word.toByteArray(Charsets.UTF_8)
        writeLength(out, bytes.size)
        out.write(bytes)
    }

    private fun writeLength(out: BufferedOutputStream, n: Int) {
        when {
            n < 0x80 -> out.write(n)
            n < 0x4000 -> { out.write((n shr 8) or 0x80); out.write(n and 0xFF) }
            n < 0x200000 -> { out.write((n shr 16) or 0xC0); out.write((n shr 8) and 0xFF); out.write(n and 0xFF) }
            n < 0x10000000 -> { out.write((n shr 24) or 0xE0); out.write((n shr 16) and 0xFF); out.write((n shr 8) and 0xFF); out.write(n and 0xFF) }
            else -> { out.write(0xF0); out.write((n shr 24) and 0xFF); out.write((n shr 16) and 0xFF); out.write((n shr 8) and 0xFF); out.write(n and 0xFF) }
        }
    }

    private fun readLength(input: BufferedInputStream): Int {
        val c = input.read()
        if (c < 0) throw IllegalStateException("ارتباط روتر قطع شد.")
        return when {
            c and 0x80 == 0 -> c
            c and 0xC0 == 0x80 -> ((c and 0x3F) shl 8) or readByte(input)
            c and 0xE0 == 0xC0 -> ((c and 0x1F) shl 16) or (readByte(input) shl 8) or readByte(input)
            c and 0xF0 == 0xE0 -> ((c and 0x0F) shl 24) or (readByte(input) shl 16) or (readByte(input) shl 8) or readByte(input)
            else -> (readByte(input) shl 24) or (readByte(input) shl 16) or (readByte(input) shl 8) or readByte(input)
        }
    }

    private fun readByte(input: BufferedInputStream): Int {
        val b = input.read()
        if (b < 0) throw IllegalStateException("ارتباط روتر قطع شد.")
        return b
    }
}
